import java.util.Scanner;

public class UnitConversion {
    private static Scanner scanner;
    private static double number;
    private static String unit;
    private static double val;

    public static void main(String args[]) {
        scanner = new Scanner(System.in);
        System.out.println("Enter any number: ");
        number = scanner.nextInt();
        System.out.println("Enter the unit of given number:");
        unit = scanner.next();
        switch (unit) {
            case "km":
                val = number * 0.62;
                System.out.println("Converted value: " + val + "mi");
                break;
            case "mi":
                val = number * 1.61;
                System.out.println("Converted value: " + val + "km");
                break;
            case "cm":
                val = number * 0.39;
                System.out.println("Converted value: " + val + "in");
                break;
            case "in":
                val = number * 2.54;
                System.out.println("Converted value: " + val + "cm");
                break;
            case "kg":
                val = number * 2.2;
                System.out.println("Converted value: " + val + "lb");
                break;
            case "lb":
                val = number * 0.45;
                System.out.println("Converted value: " + val + "kg");
                break;
            case "g":
                val = number * 0.04;
                System.out.println("Converted value: " + val + "oz");
                break;
            case "oz":
                val = number * 28.35;
                System.out.println("Converted value: " + val + "g");
                break;
            case "C":
                val = (number * 9 / 5) + 32;
                System.out.println("Converted value: " + val + "F");
                break;
            case "F":
                val = (number - 32) * 5 / 9;
                System.out.println("Converted value: " + val + "C");
                val = (number - 32) * 5 / 9 + 273.15;
                System.out.println("Converted value: " + val + "K");
                break;
            case "L":
                val = number * 4.17;
                System.out.println("Converted value: " + val + "cups");
                break;
            case "cup":
                val = number * 0.24;
                System.out.println("Converted value: " + val + "L");
                break;
            default:
                System.out.println("Invalid input");

        }
    }
}